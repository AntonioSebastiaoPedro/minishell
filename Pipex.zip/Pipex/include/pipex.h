/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipex.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ateca <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/16 11:57:35 by ateca             #+#    #+#             */
/*   Updated: 2024/08/16 11:58:51 by ateca            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PIPEX_H
# define PIPEX_H

# include <fcntl.h>
# include <stdio.h>
# include <unistd.h>
# include <stdlib.h>
# include <sys/wait.h>

char	**ft_split(char *str);
void	ft_free_split(char **split);

size_t	ft_strlen(const char *s);
void	ft_putchar_fd(char c, int fd);
void	ft_putstr_fd(char *str, int fd);
int		ft_strcmp(const char *s1, const char *s2);
int		ft_strncmp(const char *s1, const char *s2, size_t n);
char	*ft_strncpy(char *s1, char *s2, int n);
char	*ft_strjoin(char const *s1, char const delim, char const *s2);

int		ft_strlen_array(char **array);
void	print_error(char *error_message, char *param);
void	cmd_without_quotes(char *cmd_str, char **cmd, int pos1, int pos2);
char	*remove_simple_quotes(const char *str);
char	*extract_text_between_quotes(const char *input_cmd, char **cmd_split);

void	cmd_tr(char **cmd_split);
void	cmd_grep(char *cmd_str, char **cmd_split);
void	cmd_sed(char *cmd_str, char **cmd_split);
void	cmd_awk(char *cmd_str, char **cmd_split);
void	commands_with_quotes(char *cmd_str, char **cmd_split);
#endif
