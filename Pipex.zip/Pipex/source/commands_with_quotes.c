/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   commands_with_quotes.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ateca <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/27 14:23:11 by ateca             #+#    #+#             */
/*   Updated: 2024/08/27 14:23:13 by ateca            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/pipex.h"

void	cmd_tr(char **cmd_split)
{
	char	*text;

	if (ft_strcmp(cmd_split[1], "'") == 0
		&& ft_strcmp(cmd_split[2], "'") == 0)
	{
		cmd_split[1] = " ";
		cmd_split[2] = cmd_split[3];
		text = extract_text_between_quotes(cmd_split[3], cmd_split);
		if (text != NULL)
			cmd_split[2] = text;
		cmd_split[3] = NULL;
	}
	else if (ft_strcmp(cmd_split[2], "'") == 0
		&& ft_strcmp(cmd_split[3], "'") == 0)
	{
		text = extract_text_between_quotes(cmd_split[1], cmd_split);
		if (text != NULL)
			cmd_split[1] = text;
		cmd_split[2] = " ";
		cmd_split[3] = NULL;
	}
}

void	cmd_grep(char *cmd_str, char **cmd_split)
{
	int	n;

	n = ft_strlen_array(cmd_split);
	if (cmd_split[1][0] == '\'')
		cmd_without_quotes(cmd_str, cmd_split, 1, 2);
	else if (n == 3 && cmd_split[2][0] == '\'')
		cmd_without_quotes(cmd_str, cmd_split, 2, 3);
}

void	cmd_sed(char *cmd_str, char **cmd_split)
{
	if (cmd_split[1][0] == '\'')
		cmd_without_quotes(cmd_str, cmd_split, 1, 2);
}

void	cmd_awk(char *cmd_str, char **cmd_split)
{
	if (cmd_split[1][0] == '\'')
		cmd_without_quotes(cmd_str, cmd_split, 1, 2);
}

void	commands_with_quotes(char *cmd_str, char **cmd_split)
{
	if (ft_strncmp(cmd_split[0], "tr", 2) == 0)
		cmd_tr(cmd_split);
	else if (ft_strncmp(cmd_split[0], "grep", 3) == 0)
		cmd_grep(cmd_str, cmd_split);
	else if (ft_strncmp(cmd_split[0], "sed", 3) == 0)
		cmd_sed(cmd_str, cmd_split);
	else if (ft_strncmp(cmd_split[0], "awk", 3) == 0)
		cmd_sed(cmd_str, cmd_split);
}
