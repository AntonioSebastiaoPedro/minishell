/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipex_utils_extra.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ateca <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/26 16:36:03 by ateca             #+#    #+#             */
/*   Updated: 2024/08/26 16:36:06 by ateca            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/pipex.h"

void	print_error(char *error_message, char *param)
{
	ft_putstr_fd("pipex: ", 2);
	ft_putstr_fd(error_message, 2);
	if (param != NULL)
		ft_putstr_fd(param, 2);
	ft_putstr_fd("\n", 2);
	exit(EXIT_FAILURE);
}

int	ft_strlen_array(char **array)
{
	int	count;

	count = 0;
	while (array[count] != NULL)
	{
		count++;
	}
	return (count);
}

char	*ft_strchr(const char *str, int c)
{
	int	i;

	i = 0;
	while (str[i] != (char)c)
	{
		if (!str[i])
			return (NULL);
		i++;
	}
	return ((char *)str + i);
}

void	cmd_without_quotes(char *cmd_str, char **cmd_split, int pos1, int pos2)
{
	char	*text;

	text = extract_text_between_quotes(cmd_str, cmd_split);
	if (text != NULL)
	{
		cmd_split[pos1] = text;
		cmd_split[pos2] = NULL;
	}
}

char	*extract_text_between_quotes(const char *input_cmd, char **cmd_split)
{
	char	*start;
	char	*end;
	char	*result;
	size_t	length;

	start = ft_strchr(input_cmd, '\'');
	if (start == NULL)
		return (NULL);
	end = ft_strchr(start + 1, '\'');
	if (end == NULL)
		return (NULL);
	dprintf(2, "start: %s\n", start);
	dprintf(2, "end: %s\n", end);
	length = end - (start + 1);
	dprintf(2, "length: %ld\n", length);
	result = (char *)malloc(length + 1);
	if (result == NULL)
	{
		ft_free_split(cmd_split);
		perror("malloc");
		exit(EXIT_FAILURE);
	}
	ft_strncpy(result, start + 1, length);
	result[length] = '\0';
	return (result);
}
