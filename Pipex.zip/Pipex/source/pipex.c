/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipex.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ateca <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/16 11:48:51 by ateca             #+#    #+#             */
/*   Updated: 2024/08/16 11:56:30 by ateca            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/pipex.h"

// envp[i]:  PATH=/nfs/homes/ateca/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin

char	*ft_strtok(char *env_path, const char delim, char **next_path)
{
	int	i;

	if (!env_path)
		env_path = *next_path;
	i = 0;
	while (env_path[i] != '\0' && env_path[i] != delim)
		i++;
	if (env_path[i] == delim)
	{
		env_path[i] = '\0';
		*next_path = env_path + i + 1;
	}
	else
		return (NULL);
	return (env_path);
}

char	*find_path_executable(char *cmd, char *envp[])
{
	int		i;
	char	*dir;
	char	*full_path;
	char	*next_path;

	i = 0;
	while (envp[i] != NULL)
	{
		if (ft_strncmp(envp[i], "PATH", 4) == 0)
			break ;
		i++;
	}
	if (envp[i] == NULL)
		print_error("PATH variable is not set", NULL);
	dir = ft_strtok(envp[i] + 5, ':', &next_path);
	while (dir)
	{
		full_path = ft_strjoin(dir, '/', cmd);
		if (access(full_path, F_OK) == 0 && access(full_path, X_OK) == 0)
			return (full_path);
		free(full_path);
		dir = ft_strtok(NULL, ':', &next_path);
	}
	return (NULL);
}

// stdin  == 0
// stdout == 1
// stderr == 2

void	exec_first_cmd(char *argv[], int *pipe_fd, char *envp[])
{
	int		infile_fd;
	char	*cmd_path;
	char	**cmd_split;

	infile_fd = open(argv[1], O_RDONLY);
	if (infile_fd == -1)
		print_error("no such file or directory: ", argv[1]);
	if (dup2(infile_fd, 0) == -1 || dup2(pipe_fd[1], 1) == -1)
		print_error("could not dup fd", NULL);
	if (access(argv[1], R_OK) == -1)
		print_error("permission denied: ", argv[1]);
	close(infile_fd);
	close(pipe_fd[0]);
	close(pipe_fd[1]);
	cmd_split = ft_split(argv[2]);
	cmd_path = find_path_executable(cmd_split[0], envp);
	commands_with_quotes(argv[2], cmd_split);
	if (!cmd_path || execve(cmd_path, cmd_split, envp) == -1)
	{
		ft_free_split(cmd_split);
		print_error("command not found: ", argv[2]);
	}
	ft_free_split(cmd_split);
	exit(EXIT_SUCCESS);
}

void	exec_second_cmd(char *argv[], int *pipe_fd, char *envp[])
{
	int		outfile_fd;
	char	*cmd_path;
	char	**cmd_split;

	outfile_fd = open(argv[4], O_WRONLY | O_CREAT | O_TRUNC, 0644);
	if (outfile_fd == -1)
		print_error("no such file or directory: ", argv[4]);
	if (dup2(pipe_fd[0], 0) == -1 || dup2(outfile_fd, 1) == -1)
		print_error("could not dup fd: ", NULL);
	if (access(argv[4], W_OK) == -1)
		print_error("permission denied: ", argv[4]);
	close(outfile_fd);
	close(pipe_fd[0]);
	close(pipe_fd[1]);
	cmd_split = ft_split(argv[3]);
	cmd_path = find_path_executable(cmd_split[0], envp);
	commands_with_quotes(argv[3], cmd_split);
	if (!cmd_path || execve(cmd_path, cmd_split, envp) == -1)
	{
		ft_free_split(cmd_split);
		print_error("command not found: ", argv[3]);
	}
	ft_free_split(cmd_split);
	exit(EXIT_SUCCESS);
}

int	main(int argc, char *argv[], char *envp[])
{
	int		pipe_fd[2];
	pid_t	pid1;
	pid_t	pid2;

	if (argc != 5)
		print_error("invalid number of arguments", NULL);
	if (!argv[2][0] || !argv[3][0] || argv[2][0] == '\0' || argv[3][0] == '\0')
		print_error("command not found: ", NULL);
	if (pipe(pipe_fd) == -1)
		print_error("could not create pipe", NULL);
	pid1 = fork();
	if (pid1 == -1)
		print_error("could not fork process: ", NULL);
	if (pid1 == 0)
		exec_first_cmd(argv, pipe_fd, envp);
	pid2 = fork();
	if (pid2 == -1)
		print_error("could not fork process", NULL);
	if (pid2 == 0)
		exec_second_cmd(argv, pipe_fd, envp);
	close(pipe_fd[0]);
	close(pipe_fd[1]);
	waitpid(pid1, NULL, 0);
	waitpid(pid2, NULL, 0);
	return (0);
}
